How to run the files?

1) Run the Scraping and Cleaned.ipynb file which would generate the final.csv file.
2) Cleaning was performed on the final.csv file to make the final_worked_new.csv
3) This was then used by the final.ipynb.
4) Run the final.ipynb.
5) This would trigger a Tkinter GUI with a search box.
6) Enter your query in the box and click the button "Click Me!"
7) Finally you get the top 20 courses closest to your query.
8) In that GUI there is a link "Go to Course" that would direct you to the course catalog to register and view
for the courses.


Notes:
File final.csv had a lot of ambigious data. It needed a lot of manual cleaning and processing
that forms a part data cleaning and processing process. Hence, this required us to work on the 
final.csv as mentioned in the documentation to create a final_worked_new.csv.